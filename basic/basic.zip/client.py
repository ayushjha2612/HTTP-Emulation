import socket

def parse_resp(msg):
    ind1 = msg.find('\r',0)
    print("Server Response: ")
    print(msg[0: ind1])
    if(msg.find('200 OK',0)!= -1):
        ind2 = msg.find('\n', ind1+2)
        print(msg[ind2+1:])

serverIP = "10.0.1.2"

dst_ip = serverIP
s = socket.socket()

print(dst_ip)

port = 12346

s.connect((dst_ip, port))

#s.send('Hello server'.encode())
#print ('Client received '+s.recv(1024).decode())

#Write your code here:
#1. Add code to send HTTP GET / PUT / DELETE request. The request should also include KEY.
#2. Add the code to parse the response you get from the server.

#req = "PUT /assignment1/key6/val6 HTTP/1.1\r\n\r\n\r\n"
req = "GET /assignment1?request=key6 HTTP/1.1\r\n\r\n\r\n"
#req = "DELETE /assignment1/key1 HTTP/1.1\r\n\r\n\r\n"
print("Client Request: ")
print(req)

s.send(req.encode())

respmsg = s.recv(1024).decode()
parse_resp(respmsg)

s.close()
